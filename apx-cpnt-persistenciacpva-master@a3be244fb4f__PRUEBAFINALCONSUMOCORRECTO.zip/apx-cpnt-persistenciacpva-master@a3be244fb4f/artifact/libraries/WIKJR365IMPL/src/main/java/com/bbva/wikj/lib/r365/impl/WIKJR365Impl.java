package com.bbva.wikj.lib.r365.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * The WIKJR365Impl class...
 */
public class WIKJR365Impl extends WIKJR365Abstract {

	private static final Logger LOGGER = LoggerFactory.getLogger(WIKJR365Impl.class);

	/**
	 * The execute method...
	 */

	@Override
	public Map<String, Object> executeSelect(long id) {
		//Map<String, Object> list = new HashMap<>();
		//list = this.jdbcUtils.queryForMap("","");
		return this.jdbcUtils.queryForMap("wikj.querie1", id);
	}

	@Override
	public long executeInsert(Map<String, Object> args) {return this.jdbcUtils.update("wikj.querie2", args);}


}
