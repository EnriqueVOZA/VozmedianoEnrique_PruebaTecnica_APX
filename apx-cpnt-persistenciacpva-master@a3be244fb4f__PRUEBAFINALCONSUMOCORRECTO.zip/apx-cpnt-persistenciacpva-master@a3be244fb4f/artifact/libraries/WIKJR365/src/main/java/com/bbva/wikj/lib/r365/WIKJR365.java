package com.bbva.wikj.lib.r365;

import java.util.Map;

/**
 * The  interface WIKJR365 class...
 */
public interface WIKJR365 {

	/**
	 * The execute method...
	 */
	Map<String, Object> executeSelect(long id); //long id
	long executeInsert(Map<String, Object> args);
}
