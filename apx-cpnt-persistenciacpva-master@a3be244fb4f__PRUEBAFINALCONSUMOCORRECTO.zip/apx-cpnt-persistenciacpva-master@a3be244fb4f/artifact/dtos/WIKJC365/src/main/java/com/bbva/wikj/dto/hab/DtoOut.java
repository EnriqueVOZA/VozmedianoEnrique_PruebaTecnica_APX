package com.bbva.wikj.dto.hab;

public class DtoOut {

    private static final long serialVersionUID = 2931699728946643245L;

    private long id;
    private long nuip;
    private String fullName;
    private String phone;
    private String address;

    public DtoOut() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getNuip() {
        return nuip;
    }

    public void setNuip(long nuip) {
        this.nuip = nuip;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
