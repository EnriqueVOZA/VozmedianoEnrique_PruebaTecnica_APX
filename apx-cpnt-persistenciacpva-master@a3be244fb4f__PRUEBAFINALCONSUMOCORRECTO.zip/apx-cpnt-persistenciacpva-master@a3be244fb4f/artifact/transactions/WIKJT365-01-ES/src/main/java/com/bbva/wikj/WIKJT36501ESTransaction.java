package com.bbva.wikj;

import com.bbva.wikj.dto.hab.DtoOut;
import com.bbva.wikj.lib.r365.WIKJR365;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

public class WIKJT36501ESTransaction extends AbstractWIKJT36501ESTransaction {
	private static final Logger LOGGER = LoggerFactory.getLogger(WIKJT36501ESTransaction.class);

	@Override
	public void execute() {
		WIKJR365 wikjR365 = this.getServiceLibrary(WIKJR365.class);


		Map<String, Object> args = new HashMap<>();
		args.put("id", this.getDtoin().getId());
		args.put("nuip", this.getDtoin().getNuip());
		args.put("full_name", this.getDtoin().getFullName());
		args.put("phone", this.getDtoin().getPhone());
		args.put("address", this.getDtoin().getAddress());
		wikjR365.executeInsert(args);

		DtoOut dtoOut = new DtoOut();
		Long id = Long.valueOf(this.getDtoin().getId());

		Map<String, Object> select = wikjR365.executeSelect(id);

		if(select.isEmpty()){
			dtoOut.setId(0);
			this.setDtoout(dtoOut);
		}else{
			dtoOut.setId(Long.valueOf(this.getDtoin().getId()));
			dtoOut.setNuip(Long.valueOf(this.getDtoin().getNuip()));
			dtoOut.setFullName(this.getDtoin().getFullName());
			dtoOut.setPhone(this.getDtoin().getPhone());
			dtoOut.setAddress(this.getDtoin().getAddress());
			this.setDtoout(dtoOut);
		}

	}

}
